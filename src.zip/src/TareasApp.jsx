import React, { useState } from 'react'
import { ListaTareas } from './ListaDePendientes/components/ListaTareas'
import { AgregarTarea } from './ListaDePendientes/components/AgregarTarea'
import { useTareas } from './ListaDePendientes/hooks/useTareas'

export const TareasApp = () => {
  const [tareasA, setTareasA] = useState([]);
  const agregarTarea = (NewTarea) => {
    //Evalua si la categoria insertada se incluye en el array

    setTareasA([ ...tareasA,NewTarea]); 
    
  };

  return (
    <>
    
      <AgregarTarea onNewTarea={(value) =>{agregarTarea(value)}  } />
      
      {
        
        
      <ListaTareas  onNewTarea={(Object.keys(tareasA).length === 0) ? (null ):(tareasA)}/>
        
      }
      
    </>
  );
};
