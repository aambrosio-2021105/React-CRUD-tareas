import React, { useEffect, useState } from "react";
import { useTareas } from "../hooks/useTareas";

export const ListaTareas = ({ onNewTarea }) => {
  useTareas(onNewTarea);
  const imprimir =()=>{
    console.log("sucias")
  }
  return (
    <>
      <div className="container">
        <h2>Lista de usuarios</h2>
        <table className="table">
          <thead>
            <tr>
              <th scope="col">Realizada</th>
              <th scope="col">#</th>
              <th scope="col">Nombre tarea</th>
              <th scope="col">Descripcion</th>
              <th scope="col">Fecha inicio</th>
              <th scope="col">Fecha termina</th>
              <th scope="col">Estado</th>
              <th scope="col">Nombre Usuario</th>
              <th scope="col">Opciones</th>
            </tr>
          </thead>
          <tbody>
            {onNewTarea === null
              ? []
              : onNewTarea.map((t) => {
                  return (
                    <tr key={t.id}>
                      <td>
                        <div className="form-check">
                          <input
                            className="form-check-input"
                            type="checkbox"
                            value=""
                            id="flexCheckDefault"
                          />
                        </div>
                      </td>
                      <th scope="row">{t.id} </th>
                      <td>{t.nombreTarea} </td>
                      <td>{t.descripcion}</td>
                      <td>{t.fechaStart}</td>
                      <td>{t.fechaEnd} </td>
                      <td>{t.estado}</td>
                      <td>{t.nombrePersona}</td>
                      <td>
                        <button className="btn btn-warning" onClick={ () => imprimir()}>editar</button>
                        
                      </td>
                      <td>
                     
                      </td>
                    </tr>
                  );
                })}
          </tbody>
        </table>
      </div>
    </>
  );
};
