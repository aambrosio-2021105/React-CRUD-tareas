import { useState,useEffect } from "react"

export const useTareas = (onNewTarea ) => {
  
  const [tareas, setTareas] = useState([
    
    
  ]);
  
  
  const agregarTareas =  ()=>{
    
    setTareas([...tareas,onNewTarea])
    
  } 
  useEffect(() => {
    agregarTareas();
  }, [])
  
  return {
    tareas
    
  }
}
